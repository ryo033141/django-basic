from django.db import models

class BoardModel(models.Model):
    # タイトルを定義
    title = models.CharField(max_length=100)
    # 中身を定義
    content = models.TextField()
    # 投稿者を定義
    author = models.CharField(max_length=50)
    # 画像を定義
    snsimage = models.ImageField(upload_to='')
    # いいね機能を定義（データベースが空かつフォームが空でも受け付ける）
    good = models.IntegerField(null=True,blank=True,default=1)
    # 既読数を定義（データベースが空かつフォームが空でも受け付ける）
    read = models.IntegerField(null=True,blank=True,default=1)
    # 既読ボタンを押した人を定義（データベースが空かつフォームが空でも受け付ける）
    readtext = models.TextField(null=True,blank=True,default='a')