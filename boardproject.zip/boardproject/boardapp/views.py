from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.contrib.auth import authenticate, login, logout
from .models import BoardModel
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.views.generic import CreateView
from django.urls import reverse_lazy

def signupfunc(request):
    # ユーザー登録をする
    if request.method == "POST":
        # フォームで登録されたデータを取得
        username = request.POST['username']
        password = request.POST['password']
        try:
            # ユーザ登録をするオブジェクトを指定
            user = User.objects.create_user(username, "", password)
            return render(request,'signup.html',{'some':100})
        # 登録するユーザーが重複していた場合
        except IntegrityError:
            return render(request,'signup.html',{'error':'このユーザーはすでに登録されています。'})

    # HTTPレスポンスオブジェクトを作れる
    return render(request,'signup.html')

def loginfunc(request):
    # もしリクエストがPOSTの時
    if request.method == "POST":
        # ユーザー名を取得
        username = request.POST["username"]
        # パスワードを取得
        password = request.POST["password"]
        # 認証を行う
        user = authenticate(request, username=username, password=password)
        # ユーザーが存在している場合
        if user is not None:
            # ログインする
            login(request, user)
            return redirect('list')
        else:
            return render(request,'login.html',{})
    
    return render(request,'login.html',{})

@login_required
def listfunc(request):
    # BoardModelの中にあるオブジェクト全てを変数に格納
    object_list = BoardModel.objects.all()
    return render(request,'list.html',{'object_list':object_list})

def logoutfunc(request):
    logout(request)
    return redirect('login')

def detailfunc(request,pk):
    # 対象とするモデルに入っている対象とする番号のオブジェクトがあれば返す
    # 一方で、なければエラー404（not found) を返す
    object = get_object_or_404(BoardModel,pk=pk)
    return render(request,'detail.html',{'object':object})

def goodfunc(request,pk):
    # 対象とするモデルに入っている対象とする番号のオブジェクトがあれば返す
    object = BoardModel.objects.get(pk=pk)
    # いいねが押されたら数を1加算する
    object.good = object.good + 1
    # 保存する
    object.save()
    return redirect('list')

def readfunc(request,pk):
    # 対象とするオブジェクトを取得
    object = BoardModel.objects.get(pk=pk)
    # ログインをしているユーザーを取得
    username = request.user.get_username()
    # ユーザーが既に既読を押しているユーザーがいる場合
    if username in object.readtext:
        return redirect('list')
    # 既読のボタンをまだ押した事がないユーザーの場合
    else:
        # 既読数を一つ増やす
        object.read = object.read + 1
        # 既読をした人のデータを入れる
        object.readtext = object.readtext + ' ' + username
        # 保存する
        object.save()
        return redirect('list')

class BoardCreate(CreateView):
    # テンプレートを指定
    template_name = 'create.html'
    # モデルを指定
    model = BoardModel
    # フィールドを指定
    fields = ('title','content','author','snsimage')
    # データの作成が完了した後に遷移するURLを指定
    success_url = reverse_lazy('list')