from django.contrib import admin
from .models import BoardModel

# 管理画面にBoardModelを認識させる
admin.site.register(BoardModel)